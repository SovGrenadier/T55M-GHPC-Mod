﻿using System;
using MelonLoader;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using GHPC.Weapons;
using UnityEngine;
using GHPC.Camera;
using GHPC.Player;
using GHPC.Vehicle;
using GHPC.Equipment;
using GHPC.Utility;
using GHPC;
using NWH;
using NWH.VehiclePhysics;
using Reticle;
using GHPC.State;
using System.Collections;
using GHPC.Equipment.Optics;
using T55M_90;
using System.Resources;
using GHPC.Audio;
using UnityEngine.PlayerLoop;
using BehaviorDesigner.Runtime.Tasks.Unity.UnityGameObject;
using JetBrains.Annotations;
using TMPro;

[assembly: MelonInfo(typeof(T55M), "T-55M", "1.0.0", "Schweiz, VacGon (sources)")]
[assembly: MelonGame("Radian Simulations LLC", "GHPC")]

namespace T55M_90
{
    public class T55M : MelonMod
    {
        static GameObject range_readout;

        AmmoClipCodexScriptable clip_codex_bastion;
        AmmoType.AmmoClip clip_bastion;
        AmmoCodexScriptable ammo_codex_bastion;
        static public AmmoType ammo_bastion;

        AmmoClipCodexScriptable clip_codex_3bm25;
        AmmoType.AmmoClip clip_3bm25;
        AmmoCodexScriptable ammo_codex_3bm25;
        AmmoType ammo_3bm25;

        AmmoType ammo_9m111;
        AmmoType ammo_3bm20;
        AmmoType ammo_3of412;

        GameObject[] vic_gos;
        GameObject gameManager;
        PlayerInput playerManager;
        private static PlayerInput player_manager;
        private static CameraManager camera_manager;

        public IEnumerator GetVics(GameState _)
        {
            vic_gos = GameObject.FindGameObjectsWithTag("Vehicle");

            yield break;
        }

        public IEnumerator Convert(GameState _)
        {
            vic_gos = GameObject.FindGameObjectsWithTag("Vehicle");
            gameManager = GameObject.Find("_APP_GHPC_");
            playerManager = gameManager.GetComponent<PlayerInput>();

            foreach (GameObject vic_go in vic_gos)
            {
                Vehicle vic = vic_go.GetComponent<Vehicle>();

                if (vic == null) continue;
                if (vic.FriendlyName != "T-55A") continue;

                GameObject ammo_3bm25_vis = null;
                GameObject ammo_bastion_vis = null;

                // generate visual models 
                if (ammo_3bm25_vis == null)
                {
                    ammo_3bm25_vis = GameObject.Instantiate(ammo_3bm20.VisualModel);
                    ammo_3bm25_vis.name = "3bm25 visual";
                    ammo_3bm25.VisualModel = ammo_3bm25_vis;
                    ammo_3bm25.VisualModel.GetComponent<AmmoStoredVisual>().AmmoType = ammo_3bm25;
                    ammo_3bm25.VisualModel.GetComponent<AmmoStoredVisual>().AmmoScriptable = ammo_codex_3bm25;
                }

                if (ammo_bastion_vis == null)
                {
                    ammo_bastion_vis = GameObject.Instantiate(ammo_3of412.VisualModel);
                    ammo_bastion_vis.name = "bastion visual";
                    ammo_bastion.VisualModel = ammo_bastion_vis;
                    ammo_bastion.VisualModel.GetComponent<AmmoStoredVisual>().AmmoType = ammo_bastion;
                    ammo_bastion.VisualModel.GetComponent<AmmoStoredVisual>().AmmoScriptable = ammo_codex_bastion;
                }

                MelonLogger.Msg("Sucessfully loaded vis models.");

                vic._friendlyName = "T-55M";

                // convert weapon system and FCS, especially big thanks to Atlas here for letting me nip his code
                FireControlSystem fcs = vic.GetComponentInChildren<FireControlSystem>();
                UsableOptic day_optic = Util.GetDayOptic(fcs);

                GameObject guidance_computer_obj = new GameObject("guidance computer");

                LoadoutManager loadoutManager = vic.GetComponent<LoadoutManager>();
                WeaponsManager weaponsManager = vic.GetComponent<WeaponsManager>();
                WeaponSystemInfo mainGunInfo = weaponsManager.Weapons[0];                
                WeaponSystem weapon = vic.GetComponent<WeaponsManager>().Weapons[0].Weapon;
                WeaponSystem mainGun = mainGunInfo.Weapon;

                guidance_computer_obj.transform.parent = vic.transform;
                guidance_computer_obj.AddComponent<MissileGuidanceUnit>();                
                guidance_computer_obj.AddComponent<Reparent>();
                Reparent reparent = guidance_computer_obj.GetComponent<Reparent>();
                reparent.NewParent = vic_go.transform.Find("T55A_skeleton/HULL/Turret").gameObject.transform;
                reparent.Awake();

                MissileGuidanceUnit computer = guidance_computer_obj.GetComponent<MissileGuidanceUnit>();
                computer.AimElement = weapon.FCS.AimTransform;
                weapon.GuidanceUnit = computer;

                GameObject t = GameObject.Instantiate(range_readout);
                t.GetComponent<Reparent>().NewParent = Util.GetDayOptic(fcs).transform;
                t.transform.GetChild(0).transform.localPosition = new Vector3(-284.1897f, -5.5217f, 0.1f);
                t.SetActive(true);

                fcs.MaxLaserRange = 6000f;             
                fcs.LaserAim = LaserAimMode.ImpactPoint;

                mainGun.Feed.ReloadDuringMissileTracking = true;

                loadoutManager.LoadedAmmoTypes[0] = clip_codex_3bm25;
                loadoutManager.LoadedAmmoTypes[2] = clip_codex_bastion;

                // Modify carousel loadout

                FieldInfo nonFixedAmmoClipCountsByRack = typeof(GHPC.Weapons.LoadoutManager).GetField("_nonFixedAmmoClipCountsByRack", BindingFlags.NonPublic | BindingFlags.Instance);
                List<int[]> AMMO = nonFixedAmmoClipCountsByRack.GetValue(loadoutManager) as List<int[]>;
                AMMO[0] = new int[] { 7, 7, 4 };
                MelonLogger.Msg(AMMO[0][0]);
                nonFixedAmmoClipCountsByRack.SetValue(loadoutManager, new List<int[]>());
                // 18 in T55 Ready Rack
                // [0] = ap [1] = heat [2] = he/atgm
                loadoutManager.RackLoadouts[0].AmmoCounts = new int[] { 7, 7, 4 };
                for (int i = 0; i < 2; i++)
                {
                    GHPC.Weapons.AmmoRack rack = loadoutManager.RackLoadouts[i].Rack;
                    rack.ClipTypes[0] = clip_codex_3bm25.ClipType;
                    rack.ClipTypes[2] = clip_codex_bastion.ClipType;
                    Util.EmptyRack(rack);
                }
                loadoutManager.SpawnCurrentLoadout();

                PropertyInfo roundInBreech = typeof(AmmoFeed).GetProperty("AmmoTypeInBreech");
                roundInBreech.SetValue(mainGun.Feed, null);

                MethodInfo refreshBreech = typeof(AmmoFeed).GetMethod("Start", BindingFlags.Instance | BindingFlags.NonPublic);
                refreshBreech.Invoke(mainGun.Feed, new object[] { });

                MelonLogger.Msg("Configured Ammo Count.");

                // update ballistics computer
                MethodInfo registerAllBallistics = typeof(LoadoutManager).GetMethod("RegisterAllBallistics", BindingFlags.Instance | BindingFlags.NonPublic);
                registerAllBallistics.Invoke(loadoutManager, new object[] { });

                VehicleController vehiclecontroller = vic_go.GetComponent<VehicleController>();
                vehiclecontroller.engine.maxPower = 580;
                vehiclecontroller.engine.maxRPM = 3800;
                MelonLogger.Msg("Sucessfully loaded mod.");
            }

            yield break;
        }

        public override void OnSceneWasLoaded(int buildIndex, string sceneName)
        {
            if (sceneName == "MainMenu2_Scene" || sceneName == "LOADER_MENU" || sceneName == "MainMenu2-1_Scene" || sceneName == "LOADER_INITIAL" || sceneName == "t64_menu") return;

            if (!range_readout)
            {
                foreach (Vehicle obj in Resources.FindObjectsOfTypeAll(typeof(Vehicle)))
                {
                    if (obj.name == "M1IP")
                    {
                        range_readout = GameObject.Instantiate(obj.transform.Find("Turret Scripts/GPS/Optic/Abrams GPS canvas").gameObject);
                        GameObject.Destroy(range_readout.transform.GetChild(2).gameObject);
                        GameObject.Destroy(range_readout.transform.GetChild(0).gameObject);
                        range_readout.AddComponent<Reparent>();
                        range_readout.SetActive(false);
                        range_readout.hideFlags = HideFlags.DontUnloadUnusedAsset;
                        range_readout.name = "t55 range canvas";

                        TextMeshProUGUI text = range_readout.GetComponentInChildren<TextMeshProUGUI>();
                        text.color = new Color(255f, 0f, 0f);
                        text.faceColor = new Color(255f, 0f, 0f);
                        text.outlineColor = new Color(100f, 0f, 0f, 0.5f);

                        break;
                    }
                }
            }

            if (ammo_3bm25 == null)
            {
                foreach (AmmoCodexScriptable s in Resources.FindObjectsOfTypeAll(typeof(AmmoCodexScriptable)))
                {
                    if (s.AmmoType.Name == "9M111 Fagot")
                    {
                        ammo_9m111 = s.AmmoType;
                    }

                    if (s.AmmoType.Name == "3BM20 APFSDS-T")
                    {
                        ammo_3bm20 = s.AmmoType;
                    }
                    if (s.AmmoType.Name == "3OF412 HE-T")
                    {
                        ammo_3of412 = s.AmmoType;
                    }
                }

                // 3bm25 
                ammo_3bm25 = new AmmoType();
                Util.ShallowCopy(ammo_3bm25, ammo_3bm20);
                ammo_3bm25.Name = "3BM25 APFSDS-T";
                ammo_3bm25.Caliber = 100;
                ammo_3bm25.RhaPenetration = 450;
                ammo_3bm25.MuzzleVelocity = 1700f;
                ammo_3bm25.Mass = 4.85f;

                ammo_codex_3bm25 = ScriptableObject.CreateInstance<AmmoCodexScriptable>();
                ammo_codex_3bm25.AmmoType = ammo_3bm25;
                ammo_codex_3bm25.name = "ammo_3bm25";

                clip_3bm25 = new AmmoType.AmmoClip
                {
                    Capacity = 1,
                    Name = "3BM25 APFSDS-T",
                    MinimalPattern = new AmmoCodexScriptable[1]
                };
                clip_3bm25.MinimalPattern[0] = ammo_codex_3bm25;

                clip_codex_3bm25 = ScriptableObject.CreateInstance<AmmoClipCodexScriptable>();
                clip_codex_3bm25.name = "clip_3bm25";
                clip_codex_3bm25.ClipType = clip_3bm25;

                // bastion AT missile
                ammo_bastion = new AmmoType();
                Util.ShallowCopy(ammo_bastion, ammo_9m111);
                ammo_bastion.Name = "9M117-1 Бастион BLATGM";
                ammo_bastion.Caliber = 100;
                ammo_bastion.RhaPenetration = 575;
                ammo_bastion.MuzzleVelocity = 370;
                ammo_bastion.Mass = 17.6f;
                ammo_bastion.ArmingDistance = 75;
                ammo_bastion.DetonateSpallCount = 20;
                ammo_bastion.SpiralPower = 0f;
                ammo_bastion.TntEquivalentKg = 3.1f;
                ammo_bastion.TurnSpeed = 0.15f;
                ammo_bastion.SpiralAngularRate = 0f;
                ammo_bastion.RangedFuseTime = 12.5f;
                ammo_bastion.MaximumRange = 5000;
                ammo_bastion.MaxSpallRha = 18f;
                ammo_bastion.MinSpallRha = 1f;
                ammo_bastion.SpallMultiplier = 6;
                ammo_bastion.CertainRicochetAngle = 3f;
                ammo_bastion.ShotVisual = ammo_9m111.ShotVisual;
                ammo_bastion.Guidance = AmmoType.GuidanceType.Saclos;

                ammo_codex_bastion = ScriptableObject.CreateInstance<AmmoCodexScriptable>();
                ammo_codex_bastion.AmmoType = ammo_bastion;
                ammo_codex_bastion.name = "ammo_bastion";

                clip_bastion = new AmmoType.AmmoClip
                {
                    Capacity = 1,
                    Name = "9M117-1 Бастион BLATGM",
                    MinimalPattern = new AmmoCodexScriptable[1]
                };
                clip_bastion.MinimalPattern[0] = ammo_codex_bastion;

                clip_codex_bastion = ScriptableObject.CreateInstance<AmmoClipCodexScriptable>();
                clip_codex_bastion.name = "clip_bastion";
                clip_codex_bastion.ClipType = clip_bastion;
            }

            StateController.RunOrDefer(GameState.GameReady, new GameStateEventHandler(GetVics), GameStatePriority.Medium);
            StateController.RunOrDefer(GameState.GameReady, new GameStateEventHandler(Convert), GameStatePriority.Medium);
        }
    }
}